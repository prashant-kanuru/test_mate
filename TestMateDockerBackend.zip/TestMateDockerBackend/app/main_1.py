from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse 
import os
import openai
from pydantic import BaseModel
#import openai_key
openai.api_type="azure"
openai.api_base="https://dattaraj-openai-demo.openai.azure.com/"
openai.api_version="2023-03-15-preview"
openai.api_key="228d1ca392e14934812677f1c21fa2e7"
#you can replace the secret-key (over here as a string)
#openai.api_key = "xx-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
import logger

app_name=FastAPI()
origins=[
    "http://localhost",
    "http://127.0.0.1:8000",
     "http://127.0.0.1:5000"
]

app_name.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
@app_name.post("/turbo35")
async def root(prompt:Request):
    logger.log_value("Entered the Endpoint /turbo35")
    data= await prompt.json()
    logger.log_value(data)
    system=data["system"]
    user= data["user"]  
    logger.log_value("System and User were " + system + "and" + user)
    response=openai.ChatCompletion.create(engine="gpt-35-turbo",
                                          messages=[{'role':'system','content':system},
                                                    {'role':'user','content':user}],
                                                    temperature=0.8,
                                                    top_p=0.9)
    result=response['choices'][0]['message']['content']
    logger.log_value("The result is : " + result)
    return JSONResponse({
        "status":"Succeed",
        "gpt_out":result
    })
