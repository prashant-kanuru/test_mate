import requests 

url = "http://127.0.0.1:8000/gpt_out"
data = {'user' : "I will provide you a code , write unit test cases using unittest library and end with if name=='main' block function is def sum(a,b):\\n      return a+b"}

response = requests.post(url, data)
print(response.status_code)
print(response.content)
print(response.json)