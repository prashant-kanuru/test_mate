import requests
import json

url="http://127.0.0.1:8000/turbo35"

data={

    "system":"you are an epxert in python programming",
    "user":"generate unit test-cases for the function\ndef sum(a,b):\n  return a+b",
}

headers={
    "Content-Type":"application/json"
}

response=requests.post(url, json=data,headers=headers)
print(response.status_code)
print(response.content)
print(response.json)