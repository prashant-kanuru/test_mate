api_type="azure"
api_base="https://dattaraj-openai-demo.openai.azure.com/"
api_version="2023-03-15-preview"
api_key="228d1ca392e14934812677f1c21fa2e7"