from fastapi import FastAPI, Request, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse 
import os
import openai
from pydantic import BaseModel
import config



'''
config.py is a file that contains the credentials for azure for open ai api the format of file is

name: config.py

contents:

api_type="azure"
api_base= base url to azure user.
api_version= version
api_key= api key

'''


# Get the credentials 

openai.api_type= config.api_type

openai.api_base=config.api_base

openai.api_version=config.api_version

openai.api_key=config.api_key


class prompt(BaseModel):
    user: str
    
app=FastAPI()


# api for to response from chat GPT after sending a prompt
@app.post("/gpt_output")
async def root(input:prompt):  
    print("Called please wt") 
    """response=openai.ChatCompletion.create(model="gpt-35-turbo",
                                          messages=[{'role':'system','content':'system'},
                                                    {'role':'user','content':input.user}],
                                                    temperature=0.8,
                                                    top_p=0.9)
    result=response['choices'][0]['message']['content']"""
    
    response = openai.ChatCompletion.create(engine = "gpt-35-turbo",
                                            messages = [{'role' : 'system', 'content': 'system'},
                                            {'role' : 'user', 'content' : input.user}],
                                            temperature = 0.8,
                                            top_p = 0.9)
    result = response['choices'][0]['message']['content']


    return result


        

    
